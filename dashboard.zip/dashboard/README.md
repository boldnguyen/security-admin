# Build and Deploy a React Admin Dashboard App With Theming, Tables, Charts, Calendar, Kanban and More
![Shoppy](https://i.ibb.co/W6g39w3/image.png)

## Introduction
This is a code repository for the corresponding video tutorial.

## Launch your development career with project-based coaching - https://www.jsmastery.pro
